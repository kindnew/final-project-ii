-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 08:55 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prisoner`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` varchar(11) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `username` varchar(300) NOT NULL,
  `password` varchar(200) NOT NULL,
  `zone` varchar(300) NOT NULL,
  `account_type` varchar(300) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `serial_no`, `username`, `password`, `zone`, `account_type`, `status`) VALUES
(01234, '1', 'kindnew', 'Kindu@1234', 'MAJANGER', 'adminstrator', 1),
(0567, '2', 'selemon', 'Selemon@1234', 'AGNWAK', 'comissioner', 1),
(0123, '3', 'computer', 'Computer@1234', 'NUER', 'adminstrator', 1),
(0589, '4', 'rahel', 'Rahel@1234', 'NUER', 'policeofficer', 1),
(345, '5', 'kibkab', 'Kibkab@1234', 'MAJANGER', 'inspector', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `serial_no` varchar(300) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`serial_no`, `fname`, `lname`, `sex`, `age`, `photo`) VALUES
('2', 'kindnew', 'tesfa', 'male', 21, 'yengus.jpg'),
('3', 'computer', 'science', 'male', 45, 'gbu.jpg'),
('1', 'kindnew', 'tesfa', 'male', 23, 'kindu3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_message`
--

CREATE TABLE `admin_message` (
  `id` int(11) NOT NULL,
  `sender` varchar(300) NOT NULL,
  `message` text NOT NULL,
  `zone` varchar(300) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_message`
--

INSERT INTO `admin_message` (`id`, `sender`, `message`, `zone`, `status`, `date`) VALUES
(0567, 'policeofficer', 'please call me!', 'AGNWAK', 1, '2024-06-16'),
(0589, 'comissioner', 'arrest him!', 'NUER', 1, '2024-06-16');

-- --------------------------------------------------------

--
-- Table structure for table `comissioner_information`
--

CREATE TABLE `comissioner_information` (
  `fname` varchar(300) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `zone` varchar(300) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comissioner_information`
--

INSERT INTO `comissioner_information` (`fname`, `serial_no`, `lname`, `sex`, `age`, `zone`, `photo`) VALUES
('selemon', '2', 'lejisa', 'male', 25, 'AGNWAK', 'kindu4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `comissioner_message`
--

CREATE TABLE `comissioner_message` (
  `id` int(11) NOT NULL,
  `sender` varchar(500) NOT NULL,
  `message` text NOT NULL,
  `zone` varchar(300) NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comissioner_message`
--

INSERT INTO `comissioner_message` (`id`, `sender`, `message`, `zone`, `date`, `status`) VALUES
(345, 'inspector', 'how are you?', 'MAJANGER', '2024-06-18', 1),
(0589, 'policeofficer', 'please call me back!', 'NUER', '2024-06-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `sender` varchar(300) NOT NULL,
  `comment` text NOT NULL,
  `date` date NOT NULL,
  `zone` varchar(300) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `sender`, `comment`, `date`, `zone`, `status`) VALUES
(0589, '3412', 'please make it correct!', '2024-06-24', 'NUER', 0),
(0588, '3412', 'please make it approve!', '2024-06-24', 'AGNWAK', 0),
(0587, '3411', 'please call me!', '2024-06-24', 'AGNWAK', 0),
(0586, '3410', 'please text me!', '2024-06-24', 'KOMO', 0),
(0585, '3409', 'please make it correct!', '2024-06-24', 'OPO', 0);

-- --------------------------------------------------------

--
-- Table structure for table `forgive`
--

CREATE TABLE `forgive` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `zone` varchar(100) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forgive`
--

INSERT INTO `forgive` (`id`, `date`, `serial_no`, `zone`, `description`, `status`) VALUES
(345, '2024-06-28', '5', 'AGNWAK', 'I want to go to other prison office.', '0'), 
(0589, '2024-06-28', '4', 'AGNWAK', 'hi every one!', '0');

-- --------------------------------------------------------

--
-- Table structure for table `inspector_information`
--

CREATE TABLE `inspector_information` (
  `serial_no` varchar(300) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `lname` varchar(300) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `zone` varchar(300) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inspector_information`
--

INSERT INTO `inspector_information` (`serial_no`, `fname`, `lname`, `sex`, `age`, `zone`, `photo`) VALUES
('5', 'kibkab', 'metane', 'male', 27, 'MAJANGER', 'kindu4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inspector_message`
--

CREATE TABLE `inspector_message` (
  `id` int(11) NOT NULL,
  `sender` varchar(300) NOT NULL,
  `message` text NOT NULL,
  `zone` varchar(300) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inspector_message`
--

INSERT INTO `inspector_message` (`id`, `sender`, `message`, `zone`, `status`, `date`) VALUES
(01234, 'adminstrator', 'please activate my account?', 'MAJANGER', 1, '2024-06-04'),
(0567, 'comissioner', 'are you okay?', 'AGNWAK', 1, '2024-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `description` varchar(300) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `description`, `date`) VALUES
(0123, 'In Gambella all prison office are peace full today.', '2024-06-22'),
(0567, 'Hello every one?', '2024-06-06'),
(0589, ' today there is some conflict in arround opo zone.', '2024-06-16'),
(345, 'today there was conflict between agnwak and nuer.', '2024-06-18');

-- --------------------------------------------------------

--
-- Table structure for table `policeofficer_information`
--

CREATE TABLE `policeofficer_information` (
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `sex` varchar(200) NOT NULL,
  `age` varchar(300) NOT NULL,
  `zone` varchar(300) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policeofficer_information`
--

INSERT INTO `policeofficer_information` (`fname`, `lname`, `serial_no`, `sex`, `age`, `zone`, `photo`) VALUES
('rahel', 'tiruneh', '4', 'female', '23', 'NUER', 'gbu.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `policeofficer_message`
--

CREATE TABLE `policeofficer_message` (
  `id` int(11) NOT NULL,
  `sender` varchar(300) NOT NULL,
  `message` text NOT NULL,
  `zone` varchar(300) NOT NULL,
  `status` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `policeofficer_message`
--

INSERT INTO `policeofficer_message` (`id`, `sender`, `message`, `zone`, `status`, `date`) VALUES
(345, 'inspector', 'hi policeofficer?', 'MAJANGER', 1, '2024-06-20'),
(0567, 'comissioner', 'your forgive is accepted!', 'AGNWAK', 1, '2024-06-26');

-- --------------------------------------------------------

--
-- Table structure for table `prisoner_information`
--

CREATE TABLE `prisoner_information` (
  `serial_no` varchar(300) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(300) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `zone` varchar(300) NOT NULL,
  `height` double NOT NULL,
  `face_color` varchar(200) NOT NULL,
  `photo` text NOT NULL,
  `education_level` varchar(200) NOT NULL,
  `region` varchar(200) NOT NULL,
  `crimetype` varchar(300) NOT NULL,
  `parent_phone` varchar(13) NOT NULL,
  `tsp` date NOT NULL,
  `tcp` date NOT NULL,
  `dorm_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prisoner_information`
--

INSERT INTO `prisoner_information` (`serial_no`, `fname`, `mname`, `lname`, `sex`, `age`, `zone`, `height`, `face_color`, `photo`, `education_level`, `region`, `crimetype`, `parent_phone`, `tsp`, `tcp`, `dorm_no`) VALUES
('0441', 'kindu', 'tesfa', 'assaye', 'male', 23, 'NUER', 1.65, 'white', 'kindu4.jpg', 'degree', 'amhara', 'leba!', '+251940169885', '2024-06-18', '2030-06-18', 5),
('0442', 'kibrom', 'metane', 'debele', 'male', 27, 'AGNWAK', 1.70, 'white-black', 'kindu3.jpg', 'degree', 'oromo', 'zerafi!', '+251970370637', '2024-06-17', '2040-06-17', 5),
('0443', 'rich', 'tiruneh', 'challa', 'female', 23, 'MAJANGER', 1.6, 'black', 'kindu.jpg', 'degree', 'oromo', 'kill!', '+251936114461', '2024-06-18', '2030-06-18', 6),
('0444', 'solomon', 'lejisa', 'shimelis', 'male', 23, 'OPO', 1.7, 'white', 'gbu.jpg', 'degree', 'afar', 'leba', '+251987654323', '2024-06-04', '2027-01-04', 4),
('0445', 'eyasu', 'tariku', 'dejen', 'male', 24, 'KOMO', 1.65, 'white', 'gbu.jpg', 'degree', 'harer', 'leba', '+251947483647', '2024-05-22', '2029-05-22', 4),
('0446', 'workie', 'gebrie', 'gondere', 'female', 23, 'MAJANGER', 1.59, 'white-black', 'gbu.jpg', 'degree', 'tigray', 'leba', '+251998754323', '2024-05-26', '2026-05-26', 4);

-- -------------------------------------------------------

--
-- Table structure for table `prisoner_message`
--

CREATE TABLE `prisoner_message` (
  `id` int(11) NOT NULL,
  `sender` varchar(300) NOT NULL,
  `reciver` varchar(300) NOT NULL,
  `message` varchar(400) NOT NULL,
  `Date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prisoner_message`
--

INSERT INTO `prisoner_message` (`id`, `sender`, `reciver`, `message`, `Date`, `status`) VALUES
(345, 'inspector', 'comissioner', 'you are transfered from&nbsp; AGNWAK to NUER', '2024-06-08', 1),
(346, 'inspector', 'policeofficer', 'you are transfered from&nbsp; NUER to MAJANGER', '2024-06-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `orderedtype` varchar(300) NOT NULL,
  `eating_time` varchar(200) NOT NULL,
  `monday` varchar(200) NOT NULL,
  `tusday` varchar(200) NOT NULL,
  `wednsday` varchar(200) NOT NULL,
  `thursday` varchar(200) NOT NULL,
  `friday` varchar(200) NOT NULL,
  `saturday` varchar(200) NOT NULL,
  `sunday` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`orderedtype`, `eating_time`, `monday`, `tusday`, `wednsday`, `thursday`, `friday`, `saturday`, `sunday`) VALUES
('erat', '11:30 am-1:00 pm', 'atklt', 'shiro', 'keywet', 'pasta', 'shiro', 'pasta', 'shiro'),
('kurs', '12:30 am-2:00 am', 'rice', 'firfr', 'rice', 'firfr', 'firfr', 'rice', 'rice'),
('misa', '5:30 am-7:00 am', 'pasta', 'qeywet', 'qeywet', 'qeywet', 'qeywet', 'qeywet', 'qeywet');

-- --------------------------------------------------------

--
-- Table structure for table `t`
--

CREATE TABLE `t` (
  `id` int(11) NOT NULL,
  `serial_no` varchar(200) NOT NULL,
  `password` varchar(66) NOT NULL,
  `status` int(11) NOT NULL,
  `username` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t`
--

INSERT INTO `t` (`id`, `serial_no`, `password`, `status`, `username`) VALUES
(1, '5543', 'Pk3x5A', 0, 'kindu'),
(2, '2121', '0AWq9n', 0, 'kibkab'),
(3, '1512', '97dfJO', 0, 'workie'),
(4, '1512', 'IGj65y', 0, 'rahel'),
(5, '1512', 'eyasu', 0, 'eyasu'),
(6, '22222', 'qe79DF', 0, 'selemon');

-- --------------------------------------------------------

--
-- Table structure for table `visitor`
--

CREATE TABLE `visitor` (
  `id` int(11) NOT NULL,
  `fname` varchar(300) NOT NULL,
  `mname` varchar(300) NOT NULL,
  `lname` varchar(300) NOT NULL,
  `age` int(11) NOT NULL,
  `sex` varchar(11) NOT NULL,
  `prisoner` varchar(300) NOT NULL,
  `relation` varchar(300) NOT NULL,
  `region` varchar(300) NOT NULL,
  `woreda` varchar(300) NOT NULL,
  `kebele` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor`
--

INSERT INTO `visitor` (`id`, `fname`, `mname`, `lname`, `age`, `sex`, `prisoner`, `relation`, `region`, `woreda`, `kebele`) VALUES
(1, 'tesfa', 'assaye', 'tagele', 49, 'male', 'kindnew', 'father', 'amhara', 'goncha', '011'),
(2, 'metane', 'chala', 'debele', 60, 'male', 'kibkab', 'father', 'amhara', 'chilga', '035'),
(3, 'yengus', 'kefyalew', 'ejigu', 23, 'female', 'kindnew', 'girl-freind', 'amhara', 'amanueil', '034'),
(4, 'tiru', 'tesfa', 'assaye', 26, 'female', 'kindnew', 'sister', 'amhara', 'goncha', '011'),
(5, 'enate', 'aychile', 'fenta', 45, 'female', 'kindnew', 'mother', 'amhara', 'goncha', '011');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serial_no` (`serial_no`);

--
-- Indexes for table `admin_info`
--
ALTER TABLE `admin_info`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `admin_message`
--
ALTER TABLE `admin_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comissioner_information`
--
ALTER TABLE `comissioner_information`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `comissioner_message`
--
ALTER TABLE `comissioner_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forgive`
--
ALTER TABLE `forgive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inspector_information`
--
ALTER TABLE `inspector_information`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `inspector_message`
--
ALTER TABLE `inspector_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `policeofficer_information`
--
ALTER TABLE `policeofficer_information`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `policeofficer_message`
--
ALTER TABLE `policeofficer_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prisoner_information`
--
ALTER TABLE `prisoner_information`
  ADD PRIMARY KEY (`serial_no`);

--
-- Indexes for table `prisoner_message`
--
ALTER TABLE `prisoner_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`eating_time`);

--
-- Indexes for table `t`
--
ALTER TABLE `t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- AUTO_INCREMENT for table `admin_message`
--
ALTER TABLE `admin_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comissioner_message`
--
ALTER TABLE `comissioner_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `forgive`
--
ALTER TABLE `forgive`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `inspector_message`
--
ALTER TABLE `inspector_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `policeofficer_message`
--
ALTER TABLE `policeofficer_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `prisoner_message`
--
ALTER TABLE `prisoner_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `t`
--
ALTER TABLE `t`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `visitor`
--
ALTER TABLE `visitor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
