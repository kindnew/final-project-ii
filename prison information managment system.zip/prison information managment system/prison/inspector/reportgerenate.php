<?php 
session_start();
include '../connection.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
        <link rel="stylesheet" href="../decoration/css/bootstrap.min.css">

        <script src="../decoration/js/jquery.min.js"></script>
        <script src="../decoration/js/bootstrap.min.js"></script>
        <style type="text/css">
        	
body{
	font-family: Times News Roman;
}

ul li a{
	font-size: 20px;


}

 </style>
     
	<title>prisoner managment system</title>
</head>
<body>

	<div class="container" style="background-color: gray; border-radius: 16px; box-shadow: 0px 0px 10px blue;">
	<img src="../logo2.png" style="width: 100%; height: 90px ; box-shadow: 0px 0px 10px 0px green; border-radius: 0px; margin-top: 0px;">
<table class="table table-bordered ">
  <tr>

            <td style="width: 150px;" class="text-justify" rowspan="3">
              <table class="table table-bordered"><tr><th class="text-center" style="background-color: lightgray; font-size: 18px; font-family: comic sans ms;" colspan="2">NUER ZONE</th></tr>
                  <tr><td style="font-family: comic sans ms;">Total male Prisoner Register Today</td><td>        
                    <?php 
$sql="select count(serial_no) as total from prisoner_information where zone='NUER' and sex='male' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
                  <tr><td style="font-family: comic sans ms;">total female Prisoner Register Today</td><td>
                    
                    
                    <?php 
$sql="select count(serial_no) as total from prisoner_information where zone='NUER' and sex='female' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
                <tr><td style="font-family: comic sans ms;">Total Prisoner Register Today</td><td>
                    
                    
                    <?php 
$sql="select count(serial_no) as total from prisoner_information where zone='NUER' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
                 
<th class="text-center" style="background-color: lightgray; font-size: 18px; font-family: comic sans ms;" colspan="2">AGNWAK ZONE</th></tr>
              
              <tr><td style="font-family: comic sans ms;">Total male Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='AGNWAK' and sex='male' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
              <tr><td style="font-family: comic sans ms;">Total female Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='AGNWAK' and sex='female' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
                <tr><td style="font-family: comic sans ms;">Total Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='AGNWAK' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

          ?></td></tr>
                 <th class="text-center" style="background-color: lightgray; font-size: 18px; font-family: comic sans ms;" colspan="2">KOMO ZONE</th></tr>

<tr><td style="font-family: comic sans ms;">Total male Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='KOMO' and sex='male' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
<tr><td style="font-family: comic sans ms;">Total female Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='KOMO' and sex='female' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}

                 ?></td></tr>
                <tr><td style="font-family: comic sans ms;">Total Prisoner Register Today</td><td><?php 
$sql="select count(serial_no) as total from prisoner_information where zone='KOMO' and tsp='".date("Y-m-d")."'";
$query=mysqli_query($con,$sql);
$fetch=mysqli_fetch_array($query);
if ($query) {
 echo "<font style='color:red; font-family:comic sans ms; font-size:30px;'>".$fetch['total']."</font>";
}
else{
  echo "<font>0</font>";
}
                 ?> </td></tr>


            
 <script>window.print()</script>
                         
  
 </table>
</div>
</div>
</body>
</html>
<html>
<body>
</body>
</html>
