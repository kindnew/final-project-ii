<?php 
include '../connection.php';
$sql="update inspector_message set status=1 where id='".$_GET['id']."'";
$query=mysqli_query($con,$sql);
if ($query) {
	header("Location:inbox.php");
}
else{
	header("Location:inbox.php");
}

 ?>