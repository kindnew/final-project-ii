<?php 
if (isset($_POST['print'])) {
	
	echo "<script>window.print()</script>";
}


 ?>